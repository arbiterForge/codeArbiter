codeArbiter implicit state-machine audit — evidence bundle

Repository: arbiterForge/codeArbiter
Branch inspected: main
Commit: fd7eb34b2da439551443d09526ab48fd1d1bb9bf
Final live main-head observation: 2026-11-09 16:12:29 UTC; same commit.

This is a read-only development-source audit. It is not released-artifact qualification.
No repository product source, package, release, website or remote issue/Project was changed.

The two main deliverables are included in deliverables/:
- codearbiter_state_machine_audit.html: all 1,748 transition rows, 287 analytical machine families, 70 finding/boundary records, recommendations, ADR comparisons, scope and verification limits.
- codearbiter_state_machines.json: structured equivalent plus complete source-ledger metadata and per-file coverage.

The ledger count is an analytical grouping, not a product feature count or formal proof of exhaustive interleavings.
Implemented, model-guided and mixed behavior are labeled; Pi qualification helpers are test-only.

Evidence files:
- *read-files* and coverage.json distinguish full raw reads, executable-content reads, targeted reads, generated equivalence and inventory-only files.
- hook-copy-equality.json: 279 generated shared Python copies matched their canonical sources.
- surface-render-equality.json: 459 managed host surfaces matched the canonical renderer; build-surface.py --check passed for Claude/Codex/Pi.
- probe*.json: captured bounded probe observations; probe source programs are alongside them.
- Individual domain JSON ledgers preserve source references, distinctions and owner-specific evidence.
- report-validation.json verifies table/JSON preservation, IDs and source links; browser rendering was not executed.
- MANIFEST.json records SHA-256 and byte size of every enclosed file other than itself.

Probe limits:
Native Go findings were inspected statically; no Go toolchain was available.
Node/Python probes exercised actual modules with temporary fixtures or fake host/Docker/terminal dependencies.
No real Docker container, provider inference, installed GUI host, npm publication or remote Release/Project mutation was exercised.
The captured outputs demonstrate only the stated fixture observations.

Re-use:
Checkout the exact commit before rerunning any probe. Several audit scripts embed the original checkout path; inspect and adjust only local checkout/output locations for your own environment. Read each probe's dependencies and fixture boundaries before execution. These scripts are evidence, not a supported product test suite. No credentials or upload helper material is included.

The HTML is self-contained. Source links are pinned to the audited commit. Full scope limits and verification still required remain in the deliverables.
